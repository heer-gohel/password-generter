from flask import Flask, render_template, request, session, redirect, url_for, flash
import random
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = os.urandom(24)  # More secure random secret key

# OTP configuration
OTP_EXPIRY_SECONDS = 60
OTP_LENGTH = 6

# Function to send OTP via email
def send_otp(email, otp, username):
    sender_email = "priyanshutholiya116@gmail.com"
    sender_password = "mbvg trct cqrg cnrj"  # Consider using environment variables for this
    subject = "Your Secure OTP Verification Code"
    
    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = email
    message['Subject'] = subject
    
    # More professional email body
    body = f"""
    Hello {username},
    
    Your one-time password (OTP) for authentication is: 
    
    {otp}
    
    This OTP will expire in {OTP_EXPIRY_SECONDS} seconds.
    
    If you did not request this OTP, please ignore this email.
    
    Thank you,
    Security Team
    """
    
    message.attach(MIMEText(body, 'plain'))
    
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, email, message.as_string())
        server.quit()
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        
        # Generate a random OTP
        otp = ''.join([str(random.randint(0, 9)) for _ in range(OTP_LENGTH)])
        
        # Store in session
        session['username'] = username
        session['email'] = email
        session['otp'] = otp
        session['otp_expiry'] = (datetime.now() + timedelta(seconds=OTP_EXPIRY_SECONDS)).timestamp()
        
        if send_otp(email, otp, username):
            return redirect(url_for('verify'))
        else:
            flash("Failed to send OTP. Please check your email address and try again.", "danger")
    
    return render_template('index.html')

@app.route('/verify', methods=['GET', 'POST'])
def verify():
    # Check if OTP session exists
    if 'otp' not in session or 'otp_expiry' not in session:
        flash("Session expired. Please start again.", "danger")
        return redirect(url_for('index'))
    
    # Check if OTP has expired
    if datetime.now().timestamp() > session['otp_expiry']:
        flash("OTP has expired. Please request a new one.", "danger")
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        entered_otp = request.form['otp']
        if entered_otp == session.get('otp'):
            # Clear sensitive session data
            session.pop('otp', None)
            session.pop('otp_expiry', None)
            return redirect(url_for('success'))
        else:
            flash("Invalid OTP. Please try again.", "danger")
    
    # Calculate remaining time for frontend
    remaining_seconds = max(0, int(session['otp_expiry'] - datetime.now().timestamp()))
    
    return render_template('verify.html', seconds_left=remaining_seconds)

@app.route('/success')
def success():
    # Check if user is authenticated
    if 'username' not in session:
        return redirect(url_for('index'))
    
    username = session.get('username')
    return render_template('success.html', username=username)

@app.route('/resend', methods=['POST'])
def resend_otp():
    if 'email' not in session or 'username' not in session:
        flash("Session expired. Please start again.", "danger")
        return redirect(url_for('index'))
    
    # Generate new OTP
    otp = ''.join([str(random.randint(0, 9)) for _ in range(OTP_LENGTH)])
    
    # Update session
    session['otp'] = otp
    session['otp_expiry'] = (datetime.now() + timedelta(seconds=OTP_EXPIRY_SECONDS)).timestamp()
    
    if send_otp(session['email'], otp, session['username']):
        flash("New OTP has been sent to your email.", "success")
    else:
        flash("Failed to send OTP. Please try again.", "danger")
    
    return redirect(url_for('verify'))

if __name__ == '__main__':
    app.run(debug=True)